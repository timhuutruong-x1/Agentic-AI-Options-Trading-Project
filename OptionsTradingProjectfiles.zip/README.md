# Options Trading AI

A personal project to learn SQL, Tableau, and options trading (Silver Bullet ICT strategy) while building a real AI-powered trading assistant.

## What this does

- **Scans** for options trade opportunities based on IV, Greeks, and price action
- **Tracks** open positions with real-time P&L and delta monitoring
- **Backtests** strategies (including Silver Bullet ICT setups) against historical data
- **Explains** trades and market conditions using an AI agent (Claude)

## Tech stack

| Layer | Tool |
|---|---|
| Database | PostgreSQL |
| Data ingestion | Python |
| Market data | Polygon.io / Tradier |
| Visualization | Tableau |
| AI Agent | Claude API (Anthropic) |
| Version control | Git / GitHub |

## Project structure

```
options-trading-ai/
├── schema/             # SQL table definitions
│   ├── 01_market_data.sql
│   ├── 02_options_chain.sql
│   ├── 03_positions.sql
│   ├── 04_trades.sql
│   └── 05_strategies.sql
├── ingestion/          # Scripts to fetch and store market data
│   └── fetch_options_chain.py
├── agent/              # Claude AI agent logic
│   └── trading_agent.py
├── backtester/         # Strategy backtesting engine
│   └── silver_bullet.py
├── tracker/            # Open position monitor
│   └── position_tracker.py
├── .env.example        # Required environment variables (copy to .env)
└── README.md
```

## Getting started

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/options-trading-ai.git
cd options-trading-ai
```

### 2. Set up environment
```bash
cp .env.example .env
# Edit .env and add your API keys
```

### 3. Install Python dependencies
```bash
pip install psycopg2-binary python-dotenv requests anthropic
```

### 4. Set up PostgreSQL
```bash
# Create database
createdb options_trading

# Run schema files in order
psql -d options_trading -f schema/01_market_data.sql
psql -d options_trading -f schema/02_options_chain.sql
psql -d options_trading -f schema/03_positions.sql
psql -d options_trading -f schema/04_trades.sql
psql -d options_trading -f schema/05_strategies.sql
```

### 5. Run the AI agent
```bash
python agent/trading_agent.py
```

## Learning goals

- [ ] SQL — SELECT, JOIN, GROUP BY, window functions
- [ ] Tableau — connect to PostgreSQL, build P&L and Greeks dashboards
- [ ] Options basics — calls, puts, IV, Greeks, expiry
- [ ] Silver Bullet ICT strategy — FVG, liquidity sweeps, entry windows
- [ ] Agentic AI — Claude API, tool use, multi-step reasoning

## Roadmap

| Phase | Focus | Timeline |
|---|---|---|
| 1 | SQL + project setup | Months 1–2 |
| 2 | Options basics | Months 2–3 |
| 3 | Tableau dashboards | Months 3–5 |
| 4 | Silver Bullet ICT | Months 5–7 |
| 5 | AI agent + backtester | Months 7–10 |
| 6 | Live data + real trading | Months 10–12 |

## Disclaimer

This project is for educational purposes only. Nothing here is financial advice. Always paper trade before using real money.
